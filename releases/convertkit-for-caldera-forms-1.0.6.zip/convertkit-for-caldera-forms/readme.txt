=== ConvertKit for Caldera FOrms ===
Contributors:      Shelob9, Desertsnowman
Donate link:       https://calderawp.com
Tags:              calderawp, caldera forms, wpform, form, responsive
Requires at least: 4.0
Tested up to:      4.3
Stable tag: 1.0.6
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html

ConvertKit integration for Caldera Forms

== Description ==



== Installation ==

= Manual Installation =

1. Upload the entire `/convertkit-for-caldera-forms` directory to the `/wp-content/plugins/` directory.
2. Activate ConvertKit for Caldera FOrms through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 1.0.5 =
* FIX: Tags Not saved in Convertkit
* FIX: Use multiple Convertkit processors in same form
* FIX: Bug hiding other processors when Convertkit activated

= 0.1.0 =
* First release

== Upgrade Notice ==

= 0.1.0 =
First Release
